"""Optional helper: download best_model.keras from the Google Drive file used by the original repository.

This contacts Google Drive. Nothing is uploaded; you are asked for confirmation first (use --yes to skip).
Usage:  python scripts/download_model.py [--yes] [--output models/best_model.keras]
"""
from __future__ import annotations

import argparse
import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from config import get_settings  # noqa: E402


def main() -> int:
    settings = get_settings()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default=str(ROOT / "models" / "best_model.keras"))
    parser.add_argument("--yes", action="store_true", help="do not ask for confirmation")
    args = parser.parse_args()

    out = Path(args.output)
    if out.exists() and out.stat().st_size > 0:
        print(f"{out} already exists; delete it first to re-download.")
        return 0
    if not args.yes:
        answer = input("This will download the model weights from Google Drive. Continue? [y/N] ").strip().lower()
        if answer not in {"y", "yes"}:
            print("Cancelled.")
            return 1
    try:
        import gdown
    except ImportError:
        print("gdown is not installed. Run: python -m pip install gdown")
        return 2

    out.parent.mkdir(parents=True, exist_ok=True)
    url = f"https://drive.google.com/uc?id={settings.drive_model_id}"
    result = gdown.download(url, str(out), quiet=False)
    if not result or not out.exists() or out.stat().st_size == 0:
        print("Download failed. Open the Drive link in a browser, download the file manually and place it in models/.")
        return 3
    digest = hashlib.sha256(out.read_bytes()).hexdigest()
    print(f"Saved {out} ({out.stat().st_size / 1e6:.1f} MB)\nSHA-256: {digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
