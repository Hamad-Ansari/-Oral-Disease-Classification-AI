"""Oral Disease Classification AI - single entry point:  python -m streamlit run app.py"""
from __future__ import annotations

import streamlit as st

from config import get_settings
from src import pages
from src.model_loader import ModelLoadError, download_from_drive, load_model_bundle

SETTINGS = get_settings()

st.set_page_config(page_title=SETTINGS.app_name, page_icon="🦷", layout="wide", initial_sidebar_state="expanded")
pages.inject_css()


@st.cache_resource(show_spinner="Loading model...")
def get_bundle(model_path: str, metadata_path: str, auto_download: bool, drive_id: str):
    """Load once per server process. Returns (bundle, error) so failures render as friendly messages."""
    from pathlib import Path
    try:
        if auto_download and not Path(model_path).is_file():  # explicit opt-in only (ORAL_AUTO_DOWNLOAD=1)
            download_from_drive(drive_id, Path(model_path))
        return load_model_bundle(Path(model_path), Path(metadata_path)), None
    except ModelLoadError as exc:
        return None, exc


bundle, load_error = get_bundle(str(SETTINGS.model_path), str(SETTINGS.metadata_path),
                                SETTINGS.auto_download, SETTINGS.drive_model_id)

with st.sidebar:
    st.title("🦷 Oral Disease AI")
    page = st.radio("Navigate", ["Home", "Image Analysis", "Model Insights", "About and Limitations"],
                    label_visibility="collapsed")
    st.divider()
    st.caption("Experimental decision-support tool - not a medical diagnosis.")
    if bundle:
        st.caption(f"Model: {bundle.model_name} · {bundle.num_classes} classes")
    if st.button("Reload model"):
        get_bundle.clear()
        st.rerun()

if page == "Home":
    pages.render_home(SETTINGS, bundle, load_error)
elif page == "Image Analysis":
    pages.render_analysis(SETTINGS, bundle, load_error)
elif page == "Model Insights":
    pages.render_insights(SETTINGS, bundle)
else:
    pages.render_about(SETTINGS, bundle)
