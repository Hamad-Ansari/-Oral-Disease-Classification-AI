# models/

Put the trained weights here as **`best_model.keras`** (EfficientNetB0, 6 classes, input 224x224x3).

The repository this project is based on does **not** contain the weights; its original app downloaded them from
Google Drive. Options:

1. `python scripts/download_model.py` (asks before contacting Google Drive), or
2. download the file in a browser and copy it here, or
3. point to it anywhere: PowerShell `$env:ORAL_MODEL_PATH = "D:\models\best_model.keras"`.

The file is never committed (see `.gitignore`). `model_metadata.json` (project root) must come from the same
training run: it defines the class order, input size and preprocessing note.
