# Oral Disease Classification AI - Guide Book

A practical manual for running, understanding, testing, extending and presenting this project.

---

## 1. What you have

A complete Streamlit application built around the repository
`mhmdsalah10/oral-disease-classifier`:

| Item | Status |
|---|---|
| Upload -> validate -> preprocess -> predict -> explain pipeline | Built, tested |
| Model Insights page (metrics, confusion matrix, class report, class distribution, sample predictions) | Built from real repository data |
| Automated tests | 58 passing, 1 skipped (needs real weights) |
| Trained weights `best_model.keras` | **Not in the repository - you must add them** |
| Windows PowerShell setup | Written; commands were not executed on Windows (see section 14) |

**Read this first:** it is an experimental decision-support demo. It is not a diagnostic device.

---

## 2. What the original repository contained (and what was changed)

Found in the repository: `app.py` (Streamlit), `model_metadata.json`, `requirements.txt`, three PNG figures,
and a `.devcontainer`. No weights, no README, no training code, no dataset, no training history.

Facts taken from `model_metadata.json`: 6 classes (Calculus, Caries, Gingivitis, Hypodontia, Mouth Ulcer, Tooth
Discoloration), input 224x224, EfficientNetB0 chosen over a custom CNN, raw RGB 0-255 input, test accuracy 98.44 %,
macro F1 97.45 %, lowest class F1 91.73 %.

Problems in the original app and how they were handled:

| Original behaviour | Why it matters | Now |
|---|---|---|
| When weights were missing it showed **random Dirichlet "predictions"** | Fabricated results look real | Removed. No model = clear setup message, never fake output |
| Downloaded weights from Google Drive automatically at startup | Silent third-party network call | Opt-in only (`ORAL_AUTO_DOWNLOAD=1` or `scripts/download_model.py`) |
| Applied softmax whenever output did not sum to 1, silently | Mislabels scores as probabilities | Output semantics are detected, labelled and warned about |
| Dropped alpha channel with `convert("RGB")` | Transparent PNGs turn black | Composited on white; 16-bit and palette images handled |
| No EXIF rotation | Phone photos can be sideways | Orientation is corrected |
| Accepted WEBP, no size/dimension/corruption checks | Fragile and unsafe | JPG/JPEG/PNG only, size, dimension, decode checks, friendly errors |
| UI code (`st.info`) inside a cached function | Messages only appear once | Loader returns `(bundle, error)`; UI renders it every time |
| "Confidence" label, no disclaimer, no limitations | Overstates what the model knows | Disclaimer on every analysis page, honest labels, limitations page |
| No tests, deprecated `use_container_width` | Hard to maintain | 59 tests, version-aware helper |

The original's visual identity (navy/blue, EfficientNet focus, metadata-driven class list) was kept; the original
figures are reused unchanged in `reports/figures/`.

---

## 3. Installation walkthrough (Windows PowerShell)

1. Install Python 3.10-3.12 from python.org (tick "Add python.exe to PATH"). Check: `python --version`.
2. Unzip the project and open PowerShell in the folder.
3. Create and activate an environment:
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
   If you see "running scripts is disabled": `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then retry.
4. Install packages (TensorFlow is large; allow a few minutes):
   ```powershell
   python -m pip install --upgrade pip
   python -m pip install -r requirements.txt
   ```
5. Get the weights (the file the original app pulled from Google Drive):
   ```powershell
   python scripts/download_model.py
   ```
   It asks before connecting. If Drive blocks it, download `best_model.keras` in a browser and put it in `models\`.
6. Run: `python -m streamlit run app.py`.
7. Optional tests: `python -m pip install -r requirements-dev.txt` then `python -m pytest -q`.

Note on versions: tests passed with the exact versions in `requirements-tested.txt`. The ranges in
`requirements.txt` are wider and the lower bounds were not individually tested.

---

## 4. Using the app

**Home** - what the tool does, how to use it, the disclaimer, model status.

**Image Analysis**
1. Upload a JPG/JPEG/PNG (<= 10 MB). Invalid files produce a friendly message and a next step.
2. You see the image, its size/format, a *processed preview* (exactly what the model gets) and basic quality hints
   (dark, over-exposed, low contrast, small). The hints are simple heuristics, not a medical screen.
3. Press **Analyze Image**. Inference runs only on that click. Ordinary reruns reuse the stored result for the same
   image (keyed by a hash of the file), so nothing is recomputed.
4. The result card shows the most likely category, the score (labelled *Model confidence* only when the output is a
   real probability distribution), a plain description, what it means, and a next step. A bar chart shows the top three.
5. **Clear image & results** resets everything.

**Model Insights** - test metrics from `model_metadata.json`, a model comparison table, per-class F1, confusion
matrices (counts or row-normalised %), a derived classification report, class distribution (all images and test
split), the original sample-prediction figure, and a clear notice that no training history exists.

**About and Limitations** - classes, limitations, privacy.

---

## 5. How it works

```
upload bytes
  -> validate_upload()        size, extension, real format, dimensions, full decode, EXIF rotation
  -> preprocess_image()       RGB (alpha on white) -> resize 224x224 bilinear -> float32 0-255 -> (1,224,224,3)
  -> model.predict()          EfficientNetB0 (Keras), loaded once and cached
  -> interpret_output()       checks shape/NaN/Inf; probabilities? else softmax + warning
  -> PredictionResult         class, score, ranking, top-k, timing, semantics, warnings
  -> pages._render_result()   card, chart, explanation, disclaimer
```

Key design decisions:
- **No rescaling.** Metadata says raw 0-255; Keras EfficientNet normalises inside the model. Dividing by 255 would
  silently break accuracy.
- **Resize without crop**, matching the original app. The training pipeline itself is not in the repository, so this
  is the best available evidence, not a verified match.
- **Honest scores.** Even real softmax outputs are *uncalibrated*. The UI says so.
- **Graceful degradation.** Missing weights, metadata, evaluation CSVs or figures never crash the app.

---

## 6. Module reference

| File | Responsibility | Main entry points |
|---|---|---|
| `config.py` | Settings from environment variables | `get_settings()` |
| `src/validation.py` | Safe upload handling | `validate_upload`, `assess_quality`, `ImageValidationError` |
| `src/preprocessing.py` | Tensor creation | `preprocess_image`, `processed_preview`, `to_rgb` |
| `src/model_loader.py` | Metadata and model loading | `load_metadata`, `load_model_bundle`, `download_from_drive`, `ModelLoadError` |
| `src/inference.py` | Prediction | `predict`, `interpret_output`, `PredictionResult` |
| `src/evaluation.py` | Metrics from real artifacts | `load_confusion_matrix`, `classification_report_from_cm`, `cross_check_with_metadata` |
| `src/visualizations.py` | Charts | `prediction_bar`, `confusion_matrix_fig`, `class_distribution_fig`, `per_class_f1_fig` |
| `src/medical_information.py` | Class descriptions | `get_class_info` |
| `src/pages.py` | Streamlit pages | `render_home/analysis/insights/about` |
| `app.py` | Wiring | - |

`load_model_bundle(..., loader=...)` accepts an injected loader; that is how the tests use fake models.

---

## 7. Reading the results honestly

From the repository's own test set (1,599 images):

- EfficientNetB0 accuracy 98.44 %; the custom CNN reached only 53.53 %. The confusion matrices on the Insights page
  reproduce both numbers exactly (a test enforces this).
- **Weakest class: Calculus** (F1 91.73 %). Six of 67 calculus images were predicted as gingivitis, and calculus is also
  the smallest class (449 images in total). Class imbalance is a *data fact*, not a quality measure.
- The test set appears to be a held-out split of the same dataset. Scores of 98 % on that kind of split often drop on
  new devices, lighting and patients. How the dataset was collected, whether images from one patient or source appear in
  both train and test, and how much augmentation was applied are not documented. The repository's sample figure shows
  several heavily augmented-looking images.
- The model has six labels and no "healthy" label. A photo of healthy teeth will still get one of the six answers.

What would make the claims stronger: a documented dataset, patient-level splits, evaluation on external phone photos,
calibration, and review by dentists.

---

## 8. Configuration cheat sheet (PowerShell)

```powershell
$env:ORAL_MODEL_PATH = "D:\models\best_model.keras"
$env:ORAL_LOW_CONFIDENCE_THRESHOLD = "0.6"   # optional, see below
$env:ORAL_AUTO_DOWNLOAD = "1"                # opt in to Drive download at startup
python -m streamlit run app.py
```

Environment variables last only for that PowerShell window.

**Low-confidence threshold.** It is off by default because nothing in the repository justifies a number. To choose
one properly: run the model on a held-out *validation* set, fit a calibration (for example temperature scaling),
plot accuracy against confidence, and pick the confidence above which accuracy meets your target. Then set the
variable. Until then the app discloses that calibration is unvalidated.

---

## 9. Testing guide

`python -m pytest -q` runs 59 tests (58 pass, 1 skipped without weights):

| File | Covers |
|---|---|
| `test_validation.py` | valid JPG/PNG, empty, wrong extension, extension that lies, corrupt, truncated, too large/small, EXIF rotation |
| `test_preprocessing.py` | RGB/RGBA/L/P/LA/16-bit, transparency, aspect ratios, 0-255 range kept, H/W order |
| `test_model_loader.py` | success, missing/empty file, loader failure, shape mismatches, class-index consistency, Drive download |
| `test_inference.py` | probabilities vs logits, NaN/Inf, bad shapes, top-k, low confidence, model failure |
| `test_evaluation.py` | matrices reproduce metadata metrics, zero-observation classes, labelled axes, missing files |
| `test_keras_roundtrip.py` | real `.keras` save/load/predict with a tiny stand-in network |
| `test_app_smoke.py`, `test_app_e2e.py` | the real Streamlit script headless: every page without a model; upload -> Analyze -> result |

Once you add real weights, `test_real_model_integration_if_available` runs automatically.

---

## 10. Extending the project

- **New class or new model:** retrain, save `best_model.keras`, update `class_names`, `num_classes`, `img_size`,
  `preprocessing_note` in `model_metadata.json`, add a description in `medical_information.py`, replace the
  evaluation CSVs. Loader checks catch mismatches.
- **Explainability (Grad-CAM):** not implemented, deliberately - the UI must not imply the model "explains" itself.
  If you add it, label it as a visual aid and test it on known images first.
- **"Not an oral photo" screening:** needs a validated detector (for example a classifier trained on non-oral
  images plus an out-of-distribution score evaluated on held-out data). Do not add a guess.
- **Training history:** save Keras `History` to `reports/evaluation/training_history.csv` and add a chart in
  `visualizations.py` and `pages.render_insights`.
- **Clinician review of text:** have a dentist review `src/medical_information.py` before any real-world use.

---

## 11. Security and privacy checklist

- Images are read into memory only; never written to disk or logged; no third-party inference service.
- Validation limits: type, real format, 10 MB, 64-8000 px, 40 M pixels, full decode.
- `unsafe_allow_html` is used only for app-controlled markup; class names are HTML-escaped.
- Keras `.keras` files can contain code-like layers. Keras 3 loads in safe mode by default; only load weights you trust.
- The only outbound network call is the opt-in weight download from Google Drive.
- Usage statistics are off (`.streamlit/config.toml`). A public deployment sends uploads to that server - don't use
  real patient photos on one.

---

## 12. Deployment notes

See README. In short: Streamlit Community Cloud works if RAM allows TensorFlow plus the model; set
`ORAL_AUTO_DOWNLOAD=1`; don't commit weights unless using Git LFS. Docker/VM deployment is also straightforward:
install `requirements.txt`, mount `models/`, run `streamlit run app.py --server.address 0.0.0.0`.

---

## 13. FAQ / troubleshooting

**The app says the model is not available.** Weights are missing. Follow install step 5.

**"Model output size does not match 6 classes."** Weights and metadata are from different runs.

**All predictions look the same / suspiciously confident.** Check the processed preview and that you did not edit
`preprocessing_note`. Remember the model cannot say "none of these".

**Can I use WEBP?** Not by design (spec: JPG/JPEG/PNG). Add `"webp"` to `allowed_extensions` and `"WEBP"` to
`allowed_formats` in `config.py` if you want it.

**First prediction is slow.** TensorFlow warms up on first call.

**Port in use.** `python -m streamlit run app.py --server.port 8502`.

---

## 14. Verification log (what was and was not checked)

Checked on Linux, Python 3.12.3, tensorflow-cpu 2.21.0, Keras 3.15.1, Streamlit 1.66.1:
- Repository cloned and inspected; metadata parsed; figures reviewed.
- 58 tests passed, 1 skipped.
- The real Streamlit script was driven headlessly: all four pages render with no model; with a **tiny stand-in
  network** (not your model) an uploaded image goes through to a displayed result, a rerun keeps the result, a bad file
  gives a friendly error.
- Confusion matrices cross-checked against `model_metadata.json` (accuracy and every per-class F1).

**Not checked:**
- **The real weights.** They are not in the repository and the sandbox could not reach Google Drive, so the actual
  EfficientNetB0 file has never been loaded here. Compatibility with Keras 3 is likely but unverified.
- Windows PowerShell execution, GPU use, Streamlit Community Cloud deployment, mobile layout in a real browser
  (visual appearance was not screenshot-tested).
- Real-world accuracy of any kind.

---

## 15. Talking about this project (portfolio / interviews)

Honest, strong points: you turned a notebook-style demo into a tested, modular application; you removed fabricated demo
predictions; you handled output semantics and calibration honestly; you cross-validated evaluation artifacts against
metadata; and you can explain why 98 % test accuracy is not clinical evidence. Say clearly that the base model and
dataset come from the original repository's author, and describe your contribution as the application, safety, testing
and evaluation layer.
