# Oral Disease Classification AI

A Streamlit app that classifies a photo of an oral condition into one of six categories
(Calculus, Caries, Gingivitis, Hypodontia, Mouth Ulcer, Tooth Discoloration) with an EfficientNetB0 model,
and shows the prediction, a score, a plain-language explanation and model-evaluation charts.

> **Experimental decision-support tool - not a medical diagnosis.** It has not been clinically validated.
> See *Known limitations* below and read `GUIDEBOOK.md` for the full walkthrough.

Based on <https://github.com/mhmdsalah10/oral-disease-classifier>. The model metadata, evaluation figures and class
list come from that repository. **The trained weights (`best_model.keras`) are not in that repository** - you must
supply them (see step 4).

## Quick start (Windows PowerShell)

Prerequisites: Windows 10/11, **Python 3.10 - 3.12** (tested on 3.12.3), ~2 GB free disk for TensorFlow.

```powershell
# 1. Create and activate a virtual environment
python -m venv .venv
.\.venv\Scripts\Activate.ps1
#    If activation is blocked:  Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

# 2. Install dependencies
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

# 3. (optional) run the tests
python -m pip install -r requirements-dev.txt
python -m pytest -q

# 4. Add the trained model (choose one)
python scripts/download_model.py                       # asks before contacting Google Drive
#    or copy best_model.keras into .\models\
#    or: $env:ORAL_MODEL_PATH = "D:\path\to\best_model.keras"

# 5. Start the app
python -m streamlit run app.py
```

Open the URL Streamlit prints (normally <http://localhost:8501>). macOS/Linux: same steps, activate with
`source .venv/bin/activate`.

Without the weights the app still starts: **Image Analysis** shows setup instructions and **Model Insights** works
fully. It never invents predictions.

## Project layout

```
app.py                   entry point (navigation + model loading)
config.py                all settings, overridable with environment variables
model_metadata.json      class names, input size, preprocessing note, test metrics (from the original repo)
src/validation.py        upload checks, EXIF orientation, photo-quality hints
src/preprocessing.py     RGB conversion, resize, raw 0-255 float32 tensor (1,224,224,3)
src/model_loader.py      metadata + model loading, shape checks, optional Drive download
src/inference.py         output interpretation (probabilities vs logits), top-k, warnings
src/evaluation.py        confusion matrix -> classification report, cross-checks vs metadata
src/visualizations.py    plotly / seaborn figures
src/medical_information.py  plain-language class descriptions (with provenance note)
src/pages.py             Streamlit page renderers
scripts/download_model.py   optional weight download
reports/                 original figures + evaluation CSVs (+ provenance)
tests/                   59 pytest tests
```

## Configuration (environment variables)

| Variable | Default | Meaning |
|---|---|---|
| `ORAL_MODEL_PATH` | `models/best_model.keras` (then `./best_model.keras`) | Model file |
| `ORAL_METADATA_PATH` | `model_metadata.json` | Metadata file |
| `ORAL_MAX_UPLOAD_MB` | `10` | Upload size limit (also set `server.maxUploadSize` in `.streamlit/config.toml`) |
| `ORAL_OUTPUT_ACTIVATION` | `auto` | `auto`, `probabilities` or `softmax` - how raw model output is interpreted |
| `ORAL_LOW_CONFIDENCE_THRESHOLD` | *(off)* | e.g. `0.6`. Off by default because no calibration data exists to justify a value |
| `ORAL_TOP_K` | `3` | Number of predictions shown |
| `ORAL_AUTO_DOWNLOAD` | `0` | `1` = download weights from Google Drive at startup if missing (opt-in) |

PowerShell example: `$env:ORAL_LOW_CONFIDENCE_THRESHOLD = "0.6"` then start the app in the same window.

## Model, dataset and metadata expectations

- Input: RGB, 224x224, **raw float32 values 0-255** (EfficientNetB0 rescales internally - the app does not divide
  by 255 or apply ImageNet normalisation). Source: `preprocessing_note` in `model_metadata.json`.
- Output: 6 values in the class order of `model_metadata.json`. The app treats them as softmax probabilities only if
  they look like a valid distribution; otherwise it applies softmax and warns.
- `model_metadata.json` must come from the same training run as the weights; shape mismatches are detected at load.
- Evaluation CSVs: rows = true label, columns = predicted label (`reports/evaluation/`).

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Model file not found" | Complete step 4; check `ORAL_MODEL_PATH` |
| "The model file could not be loaded" | Partial download? Re-run the download. Try a TensorFlow version near the training one (`pip install "tensorflow>=2.16,<2.22"`) |
| `ModuleNotFoundError: tensorflow` | Activate the venv, then `python -m pip install -r requirements.txt` |
| Script execution disabled | `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` |
| Port busy | `python -m streamlit run app.py --server.port 8502` |
| Google Drive download fails | Open the file in a browser, download manually, put it in `models/` |
| Very slow first prediction | Normal: TensorFlow initialises on first use |

## CPU / GPU

CPU-only inference is the default and is fast enough for single images. Native Windows TensorFlow (2.11+) has no GPU
support; for GPU use WSL2 or Linux with the matching CUDA build. Not needed for this app.

## Deploying to Streamlit Community Cloud (optional)

1. Push this project (without weights, see `.gitignore`) to GitHub.
2. Create the app with main file `app.py` and Python 3.11 or 3.12.
3. Set `ORAL_AUTO_DOWNLOAD=1` in the app's *Secrets/Environment* so the weights are fetched from Drive on first start,
   or commit them with Git LFS if allowed.
4. Caveat: TensorFlow plus the model needs a fair amount of RAM; the free tier is limited. Test before relying on it.
   Uploaded photos are processed on the host server, so do not use a public deployment for real patient images.

## Known limitations

- Not clinically validated or regulator-approved. Cannot diagnose or exclude disease.
- Closed set: always returns one of six labels; no "healthy" or "not an oral photo" class; no out-of-distribution
  detection was validated.
- Scores are uncalibrated. 98.44 % test accuracy (from the repo) is on a held-out split of the same dataset; real
  photos will likely do worse. Dataset origin and patient diversity are undocumented.
- Confusion matrices in `reports/evaluation/` were transcribed from the repository's figures (cross-checked by tests).
- Class descriptions are general educational text written for this app, not clinically reviewed.

## Tests

`python -m pytest -q` - validation, preprocessing, model loading/failure, class consistency, output interpretation,
low-confidence handling, confusion-matrix generation, missing optional files, a real Keras save/load round trip with a
tiny stand-in network, and headless end-to-end runs of the Streamlit script. One test is skipped until real weights are
present (`tests/test_inference.py::test_real_model_integration_if_available`).
