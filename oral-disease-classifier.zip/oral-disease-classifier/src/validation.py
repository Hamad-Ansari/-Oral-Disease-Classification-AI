"""Upload validation. Nothing here claims an image is 'unrelated' or 'healthy'."""
from __future__ import annotations

import hashlib
import io
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError


class ImageValidationError(Exception):
    """Raised for any upload problem. `hint` is a friendly next step for the user."""

    def __init__(self, message: str, hint: str = ""):
        super().__init__(message)
        self.message = message
        self.hint = hint


@dataclass(frozen=True)
class ImageInfo:
    width: int
    height: int
    format: str
    mode: str
    size_bytes: int
    sha256: str


def validate_upload(data: bytes, filename: str, settings) -> tuple[Image.Image, ImageInfo]:
    """Validate raw bytes and return a fully decoded, orientation-corrected PIL image."""
    if not data:
        raise ImageValidationError("The file is empty.", "Choose a JPG or PNG photograph and try again.")
    if len(data) > settings.max_upload_bytes:
        mb = len(data) / (1024 * 1024)
        raise ImageValidationError(
            f"The file is too large ({mb:.1f} MB; limit {settings.max_upload_mb:g} MB).",
            "Resize or compress the photo, then upload it again.",
        )

    ext = Path(filename or "").suffix.lower().lstrip(".")
    if ext and ext not in settings.allowed_extensions:
        raise ImageValidationError(
            f"Unsupported file type '.{ext}'.",
            "Supported formats: " + ", ".join(e.upper() for e in settings.allowed_extensions) + ".",
        )

    try:
        probe = Image.open(io.BytesIO(data))
        probe.verify()  # structural check; the object is unusable afterwards
    except (UnidentifiedImageError, OSError, SyntaxError, ValueError) as exc:
        raise ImageValidationError(
            "This file could not be read as an image; it may be corrupted or not a real picture.",
            "Re-export the photo (or take a new one) and upload it again.",
        ) from exc

    try:
        img = Image.open(io.BytesIO(data))
        fmt = (img.format or "").upper()
        if fmt not in settings.allowed_formats:
            raise ImageValidationError(
                f"The file content is {fmt or 'an unknown format'}, not JPEG or PNG.",
                "Convert the image to JPG or PNG and try again.",
            )
        width, height = img.size
        if min(width, height) < settings.min_side_px:
            raise ImageValidationError(
                f"The image is too small ({width}x{height} px).",
                f"Use a photo whose shorter side is at least {settings.min_side_px} px.",
            )
        if max(width, height) > settings.max_side_px or width * height > settings.max_pixels:
            raise ImageValidationError(
                f"The image dimensions are too large ({width}x{height} px).",
                "Downscale the photo (for example to 2000 px on the longest side) and retry.",
            )
        img.load()  # full decode: catches truncated files
        mode = img.mode
        img = ImageOps.exif_transpose(img)  # applies camera rotation, removes the orientation tag
        img = img.copy()
    except ImageValidationError:
        raise
    except (OSError, SyntaxError, ValueError, Image.DecompressionBombError) as exc:
        raise ImageValidationError(
            "The image appears to be truncated or cannot be decoded.",
            "Try exporting the photo again from your camera or gallery.",
        ) from exc

    info = ImageInfo(
        width=img.size[0],
        height=img.size[1],
        format=fmt,
        mode=mode,
        size_bytes=len(data),
        sha256=hashlib.sha256(data).hexdigest(),
    )
    return img, info


def assess_quality(img: Image.Image, model_input: tuple[int, int] = (224, 224)) -> list[str]:
    """Simple heuristic photo-quality hints. They are NOT diagnostic and NOT a validated screen."""
    hints: list[str] = []
    gray = np.asarray(img.convert("L").resize((128, 128)), dtype=np.float32)
    mean, std = float(gray.mean()), float(gray.std())
    if mean < 40:
        hints.append("The photo looks very dark. Better lighting may give a more reliable result.")
    elif mean > 225:
        hints.append("The photo looks over-exposed. Reduce glare or bright light and try again.")
    if std < 15:
        hints.append("The photo has very low contrast, which can make results less reliable.")
    if min(img.size) < min(model_input):
        hints.append(
            f"The image is smaller than the model input ({model_input[1]}x{model_input[0]}) and will be enlarged."
        )
    return hints
