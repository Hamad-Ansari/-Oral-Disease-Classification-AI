"""Evaluation helpers that work ONLY on real artifacts shipped in reports/evaluation and the metadata file."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

CONFUSION_FILES = {
    "EfficientNetB0": "efficientnetb0_confusion_matrix.csv",
    "Custom_CNN": "custom_cnn_confusion_matrix.csv",
}
CLASS_DISTRIBUTION_FILE = "class_distribution_all_images.csv"


def load_confusion_matrix(path: Path) -> Optional[pd.DataFrame]:
    """Rows = true label, columns = predicted label. Returns None if missing/invalid."""
    path = Path(path)
    if not path.is_file():
        return None
    try:
        df = pd.read_csv(path, index_col=0)
    except Exception:  # noqa: BLE001
        return None
    if df.shape[0] != df.shape[1] or df.empty:
        return None
    df = df.apply(pd.to_numeric, errors="coerce")
    if df.isna().any().any() or (df.values < 0).any():
        return None
    return df.astype(int)


def classification_report_from_cm(cm: pd.DataFrame) -> pd.DataFrame:
    """Precision / recall / F1 / support per class. Classes with no observations get 0 (no crash)."""
    m = cm.values.astype(float)
    tp = np.diag(m)
    pred_totals = m.sum(axis=0)
    support = m.sum(axis=1)
    precision = np.divide(tp, pred_totals, out=np.zeros_like(tp), where=pred_totals > 0)
    recall = np.divide(tp, support, out=np.zeros_like(tp), where=support > 0)
    denom = precision + recall
    f1 = np.divide(2 * precision * recall, denom, out=np.zeros_like(tp), where=denom > 0)
    return pd.DataFrame(
        {"Class": list(cm.index), "Precision": precision, "Recall": recall, "F1-score": f1, "Support": support.astype(int)}
    )


def summary_from_cm(cm: pd.DataFrame) -> dict:
    report = classification_report_from_cm(cm)
    total = int(cm.values.sum())
    seen = report["Support"] > 0
    weights = report["Support"] / max(total, 1)
    return {
        "accuracy": float(np.trace(cm.values) / total) if total else 0.0,
        "macro_precision": float(report.loc[seen, "Precision"].mean()) if seen.any() else 0.0,
        "macro_recall": float(report.loc[seen, "Recall"].mean()) if seen.any() else 0.0,
        "macro_f1": float(report.loc[seen, "F1-score"].mean()) if seen.any() else 0.0,
        "weighted_f1": float((report["F1-score"] * weights).sum()),
        "total": total,
    }


def cross_check_with_metadata(cm: pd.DataFrame, model_name: str, metadata: dict, tol_pct: float = 0.06) -> list:
    """Compare matrix-derived per-class F1 with the F1 values stored in model_metadata.json.

    Returns a list of human-readable mismatches (empty list = consistent).
    """
    problems: list = []
    reference = {row["Class Name"]: row.get(model_name) for row in metadata.get("per_class_f1_comparison", [])}
    if not reference:
        return ["No per-class F1 reference in metadata."]
    report = classification_report_from_cm(cm).set_index("Class")
    for cls, ref in reference.items():
        if ref is None or cls not in report.index:
            problems.append(f"{cls}: missing in matrix or metadata")
            continue
        computed = float(report.loc[cls, "F1-score"]) * 100.0
        if abs(computed - float(ref)) > tol_pct:
            problems.append(f"{cls}: matrix F1 {computed:.2f}% vs metadata {float(ref):.2f}%")
    return problems


def load_class_distribution(eval_dir: Path) -> Optional[pd.DataFrame]:
    path = Path(eval_dir) / CLASS_DISTRIBUTION_FILE
    if not path.is_file():
        return None
    try:
        df = pd.read_csv(path)
    except Exception:  # noqa: BLE001
        return None
    return df if {"class", "images"}.issubset(df.columns) else None


def metadata_comparison_table(metadata: dict) -> Optional[pd.DataFrame]:
    rows = metadata.get("all_models_comparison")
    return pd.DataFrame(rows) if rows else None


def metadata_per_class_f1(metadata: dict) -> Optional[pd.DataFrame]:
    rows = metadata.get("per_class_f1_comparison")
    return pd.DataFrame(rows) if rows else None


def missing_artifacts_message(eval_dir: Path, names: list) -> str:
    listing = "\n".join(f"- `{Path(eval_dir) / n}`" for n in names)
    return "These optional evaluation files are not available, so the related chart is hidden:\n" + listing
