"""Oral Disease Classification AI - reusable modules."""
