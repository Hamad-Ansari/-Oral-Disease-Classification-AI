"""Figure builders. Each returns a figure object; nothing is drawn from invented data."""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402
import plotly.graph_objects as go  # noqa: E402
import seaborn as sns  # noqa: E402

NAVY = "#12355B"
TEAL = "#0E9AA7"
BLUE = "#2F6DB5"
LIGHT = "#E6F3F5"


def prediction_bar(ranking: list, title: str = "Top predictions", value_label: str = "Model score (%)") -> go.Figure:
    """Sorted horizontal bar chart for [(class, score 0-1), ...] (highest score on top)."""
    names = [r[0] for r in ranking][::-1]
    values = [round(r[1] * 100.0, 2) for r in ranking][::-1]
    colors = [TEAL if i == len(values) - 1 else "#9CC9D0" for i in range(len(values))]
    fig = go.Figure(go.Bar(x=values, y=names, orientation="h", marker_color=colors,
                           text=[f"{v:.2f}%" for v in values], textposition="outside", cliponaxis=False))
    fig.update_layout(
        title=title, height=60 + 60 * len(values), margin=dict(l=10, r=40, t=50, b=30),
        xaxis=dict(range=[0, 112], title=value_label), yaxis=dict(title=""),
        plot_bgcolor="white", paper_bgcolor="white", font=dict(color=NAVY),
    )
    return fig


def confusion_matrix_fig(cm: pd.DataFrame, title: str, normalize: bool = False):
    """Heat-map with class names on both axes. normalize=True shows row-wise percentages (recall view)."""
    values = cm.values.astype(float)
    if normalize:
        row_sums = values.sum(axis=1, keepdims=True)
        shown = (values / row_sums * 100.0) if (row_sums > 0).all() else \
            values / (row_sums + (row_sums == 0)) * 100.0  # zero-observation rows stay at 0
        fmt = ".1f"
        cbar_label = "% of true class"
    else:
        shown, fmt, cbar_label = values, ".0f", "Image count"
    fig, ax = plt.subplots(figsize=(7.2, 6.0))
    sns.heatmap(shown, annot=True, fmt=fmt, cmap="Blues", cbar_kws={"label": cbar_label},
                xticklabels=list(cm.columns), yticklabels=list(cm.index), ax=ax, linewidths=0.5, linecolor="white")
    ax.set_xlabel("Predicted label")
    ax.set_ylabel("True label")
    ax.set_title(title + (" (row-normalised %)" if normalize else " (counts)"), color=NAVY, fontweight="bold")
    plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
    fig.tight_layout()
    return fig


def class_distribution_fig(df: pd.DataFrame, title: str, count_col: str, label_col: str = "class") -> go.Figure:
    fig = go.Figure(go.Bar(x=df[label_col], y=df[count_col], marker_color=BLUE,
                           text=df[count_col], textposition="outside"))
    fig.update_layout(title=title, height=360, margin=dict(l=10, r=10, t=50, b=40),
                      yaxis_title="Images", plot_bgcolor="white", paper_bgcolor="white", font=dict(color=NAVY))
    return fig


def per_class_f1_fig(df: pd.DataFrame) -> go.Figure:
    """Grouped bars from metadata per_class_f1_comparison (columns: Class Name + one column per model)."""
    fig = go.Figure()
    palette = [TEAL, "#9AA8B8", BLUE, NAVY]
    for i, col in enumerate([c for c in df.columns if c != "Class Name"]):
        fig.add_bar(name=col, x=df["Class Name"], y=df[col], marker_color=palette[i % len(palette)])
    fig.update_layout(barmode="group", title="Per-class F1-score on the test set (%)", height=380,
                      yaxis=dict(range=[0, 105], title="F1 (%)"), plot_bgcolor="white", paper_bgcolor="white",
                      margin=dict(l=10, r=10, t=50, b=40), font=dict(color=NAVY),
                      legend=dict(orientation="h", y=-0.2))
    return fig
