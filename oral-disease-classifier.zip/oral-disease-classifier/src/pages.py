"""Streamlit page renderers. Kept separate so app.py stays a thin entry point."""
from __future__ import annotations

import html
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st
from PIL import Image

from . import evaluation as ev
from . import visualizations as viz
from .inference import InferenceError, predict
from .medical_information import GENERAL_NEXT_STEP, SOURCE_NOTE, get_class_info
from .model_loader import ModelLoadError
from .preprocessing import PreprocessingError, processed_preview
from .validation import ImageValidationError, assess_quality, validate_upload

DISCLAIMER = (
    "**Experimental decision-support tool - not a medical diagnosis.** Results are informational and are "
    "not a substitute for a professional dental evaluation."
)

CSS = """
<style>
.block-container {padding-top: 2rem; max-width: 1150px;}
.hero {background: linear-gradient(135deg,#12355B 0%,#0E7C8A 100%); color:#fff; padding:1.6rem 1.8rem; border-radius:14px; margin-bottom:1rem;}
.hero h1 {color:#fff; font-size:2rem; margin:0 0 .3rem 0;}
.hero p {color:#E6F3F5; margin:0; font-size:1.02rem;}
.result-card {background:#F4FAFB; border-left:6px solid #0E9AA7; padding:1.1rem 1.3rem; border-radius:10px; margin-bottom:.9rem; color:#12355B;}
.result-card .lbl {font-size:.78rem; text-transform:uppercase; letter-spacing:.05em; font-weight:700; color:#476582;}
.result-card .cls {font-size:1.75rem; font-weight:800; margin:.15rem 0;}
.badge {display:inline-block; background:#12355B; color:#fff; padding:.25rem .8rem; border-radius:999px; font-weight:600; font-size:.9rem;}
.kv {color:#476582; font-size:.88rem;}
@media (max-width: 640px){ .hero h1{font-size:1.5rem;} .result-card .cls{font-size:1.35rem;} }
</style>
"""


def _stretch() -> dict:
    """Streamlit >=1.50 uses width='stretch'; older releases use use_container_width=True."""
    try:
        major, minor = (int(x) for x in st.__version__.split(".")[:2])
    except ValueError:
        major, minor = 1, 0
    return {"width": "stretch"} if (major, minor) >= (1, 50) else {"use_container_width": True}


def inject_css() -> None:
    st.markdown(CSS, unsafe_allow_html=True)


def render_disclaimer() -> None:
    st.warning(DISCLAIMER, icon="⚠️")


# --------------------------------------------------------------------------- Home
def render_home(settings, bundle, load_error) -> None:
    st.markdown(
        f'<div class="hero"><h1>{html.escape(settings.app_name)}</h1>'
        "<p>Upload a photograph of an oral condition and a trained image-classification model returns its "
        "most likely category, a score, and a short plain-language explanation.</p></div>",
        unsafe_allow_html=True,
    )
    render_disclaimer()
    c1, c2, c3 = st.columns(3)
    c1.markdown("**1. Upload**\n\nJPG, JPEG or PNG, up to "
                f"{settings.max_upload_mb:g} MB.")
    c2.markdown("**2. Analyze**\n\nPress *Analyze Image*; the model runs once per image.")
    c3.markdown("**3. Review**\n\nSee the top predictions, scores and suggested next steps.")
    if bundle is not None:
        st.success(f"Model ready: {bundle.model_name} · {bundle.num_classes} classes · {bundle.framework}")
    else:
        st.info("The trained model is not loaded yet. Open **Image Analysis** for setup instructions.")
    st.caption("Open **Image Analysis** in the sidebar to begin.")


# ------------------------------------------------------------------ Image Analysis
def _show_load_problem(load_error: ModelLoadError | None) -> None:
    if load_error is None:
        return
    st.error(f"Model not available: {load_error.message}")
    if load_error.troubleshooting:
        st.code(load_error.troubleshooting, language="text")
    st.caption("You can still upload an image to validate and preview it; analysis is disabled until the model loads.")


def _sample_files(settings) -> list:
    folder = Path(settings.sample_dir)
    if not folder.is_dir():
        return []
    return sorted(p for p in folder.iterdir() if p.suffix.lower().lstrip(".") in settings.allowed_extensions)


def render_analysis(settings, bundle, load_error) -> None:
    st.header("Image Analysis")
    render_disclaimer()
    _show_load_problem(load_error)

    state = st.session_state
    state.setdefault("uploader_nonce", 0)
    state.setdefault("analysis", None)

    up_col, clr_col = st.columns([4, 1])
    with up_col:
        uploaded = st.file_uploader(
            "Upload a photograph (JPG, JPEG, PNG)",
            type=list(settings.allowed_extensions),
            key=f"uploader_{state['uploader_nonce']}",
            help="Images are processed in memory and are not saved by this app.",
        )
    with clr_col:
        st.write("")
        st.write("")
        if st.button("Clear image & results"):
            state["uploader_nonce"] += 1
            state["analysis"] = None
            st.rerun()

    data, name = None, ""
    if uploaded is not None:
        data, name = uploaded.getvalue(), uploaded.name
    else:
        samples = _sample_files(settings)
        if samples:
            choice = st.selectbox("...or choose a sample image", ["(none)"] + [p.name for p in samples])
            if choice != "(none)":
                path = Path(settings.sample_dir) / choice
                data, name = path.read_bytes(), choice

    if data is None:
        st.info("Upload an image to begin. Supported formats: JPG, JPEG, PNG.")
        return

    try:
        image, info = validate_upload(data, name, settings)
    except ImageValidationError as exc:
        st.error(exc.message)
        if exc.hint:
            st.caption(f"What to do: {exc.hint}")
        return

    left, right = st.columns([1, 1.25], gap="large")
    with left:
        st.subheader("Uploaded image")
        st.image(image, caption=name or "image", **_stretch())
        st.caption(f"{info.width}×{info.height} px · {info.format} · {info.mode} · {info.size_bytes / 1024:.0f} KB")
        input_size = bundle.input_size if bundle else (224, 224)
        with st.expander("Image the model will see (processed preview)"):
            st.image(processed_preview(image, input_size),
                     caption=f"{input_size[1]}×{input_size[0]} RGB, values 0-255", width=224)
        for hint in assess_quality(image, input_size):
            st.warning(hint + " (basic heuristic check, not a diagnosis)")

    with right:
        analyze = st.button("Analyze Image", type="primary", disabled=bundle is None)
        if analyze and bundle is not None:
            try:
                with st.spinner("Running the model..."):
                    result = predict(bundle, image, settings)
                state["analysis"] = {"sha": info.sha256, "result": result}
            except (InferenceError, PreprocessingError) as exc:
                state["analysis"] = None
                st.error(f"Analysis failed: {exc}")

        stored = state.get("analysis")
        if stored and stored["sha"] == info.sha256:
            _render_result(stored["result"], settings)
        elif bundle is not None:
            st.info("Press **Analyze Image** to run the model on this picture.")


def _render_result(result, settings) -> None:
    info = get_class_info(result.top_class)
    st.subheader("Prediction")
    st.markdown(
        '<div class="result-card"><div class="lbl">Most likely category</div>'
        f'<div class="cls">{html.escape(result.top_class)}</div>'
        f'<span class="badge">{html.escape(result.score_label)}: {result.top_score * 100:.2f}%</span>'
        f'<div class="kv" style="margin-top:.5rem">{html.escape(result.semantics)}</div></div>',
        unsafe_allow_html=True,
    )
    if result.low_confidence:
        st.warning(result.warnings[0])
    if info:
        st.markdown(f"**What it is:** {info['description']}")
        st.markdown(f"**What this result means:** {info['meaning']} It is a model output, not a confirmed diagnosis.")
        st.markdown(f"**Suggested next step:** {info['next_step']} {GENERAL_NEXT_STEP}")
        st.caption(SOURCE_NOTE)
    else:
        st.markdown(f"**Suggested next step:** {GENERAL_NEXT_STEP}")

    st.plotly_chart(viz.prediction_bar(result.top_k(settings.top_k), f"Top {settings.top_k} predictions"),
                    **_stretch())
    st.caption("Alternative predictions are competing model outputs, not confirmed diagnoses.")

    with st.expander("All class scores"):
        table = pd.DataFrame(result.ranking, columns=["Class", "Score"])
        table["Score (%)"] = (table.pop("Score") * 100).round(2)
        st.dataframe(table, hide_index=True, **_stretch())
    with st.expander("Model & run details"):
        st.markdown(
            f"- Model: **{result.model_name}** ({result.framework})\n"
            f"- Input tensor: `{result.input_shape}`\n"
            f"- Preprocessing: {result.preprocessing_note or 'n/a'}\n"
            f"- Inference time: {result.inference_ms:.0f} ms\n"
            f"- Score meaning: {result.semantics}"
        )
    for warning in result.warnings[1 if result.low_confidence else 0:]:
        st.caption(f"ℹ️ {warning}")


# ------------------------------------------------------------------ Model Insights
def render_insights(settings, bundle) -> None:
    st.header("Model Insights")
    st.caption("Every number below comes from files in the original repository (model_metadata.json and its "
               "evaluation figures). Provenance is listed in reports/evaluation/README.md.")
    metadata = bundle.metadata if bundle else _safe_metadata(settings)
    if not metadata:
        st.error("model_metadata.json could not be read, so no evaluation summary is available.")
        return

    metrics = metadata.get("test_metrics") or {}
    if metrics:
        st.subheader(f"Test-set summary - {metadata.get('best_model_name', 'selected model')}")
        cols = st.columns(4)
        for col, (label, key) in zip(cols, [("Accuracy", "accuracy"), ("Macro precision", "macro_precision"),
                                            ("Macro recall", "macro_recall"), ("Macro F1", "macro_f1")]):
            val = metrics.get(key)
            col.metric(label, f"{val * 100:.2f}%" if isinstance(val, (int, float)) else "N/A")
        st.caption("Source: model_metadata.json (test_metrics). The dataset, its patient/source coverage and the "
                   "split procedure are not documented in the repository, so real-world accuracy is unknown.")
    comparison = ev.metadata_comparison_table(metadata)
    if comparison is not None:
        st.markdown("**Models compared**")
        st.dataframe(comparison, hide_index=True, **_stretch())
    per_class = ev.metadata_per_class_f1(metadata)
    if per_class is not None:
        st.plotly_chart(viz.per_class_f1_fig(per_class), **_stretch())

    st.subheader("Confusion matrix & classification report")
    available = {n: ev.load_confusion_matrix(settings.eval_dir / f) for n, f in ev.CONFUSION_FILES.items()}
    available = {n: m for n, m in available.items() if m is not None}
    if available:
        chosen = st.selectbox("Model", list(available), index=0)
        mode = st.radio("Display", ["Counts", "Row-normalised %"], horizontal=True)
        cm = available[chosen]
        fig = viz.confusion_matrix_fig(cm, f"{chosen} - test set", normalize=(mode != "Counts"))
        st.pyplot(fig)
        plt.close(fig)
        problems = ev.cross_check_with_metadata(cm, chosen, metadata)
        if problems:
            st.warning("This matrix does not fully agree with model_metadata.json: " + "; ".join(problems))
        else:
            st.caption("Matrix transcribed from the repository's evaluation figure; derived accuracy and per-class "
                       "F1 agree with model_metadata.json.")
        report = ev.classification_report_from_cm(cm)
        for col in ("Precision", "Recall", "F1-score"):
            report[col] = (report[col] * 100).round(2)
        st.markdown("**Classification report (derived from the matrix, values in %)**")
        st.dataframe(report, hide_index=True, **_stretch())
    else:
        st.info(ev.missing_artifacts_message(settings.eval_dir, list(ev.CONFUSION_FILES.values())))

    st.subheader("Class distribution")
    dist = ev.load_class_distribution(settings.eval_dir)
    if dist is not None:
        st.plotly_chart(viz.class_distribution_fig(dist, f"All images ({int(dist['images'].sum()):,} total; "
                                                         "split not specified in the source)", "images"),
                        **_stretch())
        if "EfficientNetB0" in available:
            sup = ev.classification_report_from_cm(available["EfficientNetB0"])[["Class", "Support"]]
            st.plotly_chart(viz.class_distribution_fig(sup, f"Test split ({int(sup['Support'].sum()):,} images)",
                                                       "Support", "Class"), **_stretch())
        st.caption("Class balance describes the data only; it is not evidence of model quality. Calculus has the "
                   "fewest images, and it also has the lowest F1 of the six classes.")
    else:
        st.info(ev.missing_artifacts_message(settings.eval_dir, [ev.CLASS_DISTRIBUTION_FILE]))

    st.subheader("Training history")
    st.info("No saved training logs (accuracy/loss curves) exist in the repository, so this chart is unavailable. "
            "Add a `reports/evaluation/training_history.csv` exported from your training run to enable it.")

    st.subheader("Sample predictions (from the original repository)")
    sample_fig = Path(settings.figures_dir) / "test_sanity_check_6_images.png"
    if sample_fig.is_file():
        st.image(Image.open(sample_fig), caption="Output saved by the original training notebook (EfficientNetB0, 6 test images).",
                 **_stretch())
        st.caption("These were produced during the original project, not by this app. Several dataset images look "
                   "heavily augmented, so everyday phone photos may behave differently.")
    else:
        st.info("test_sanity_check_6_images.png is missing from reports/figures.")


def _safe_metadata(settings) -> dict:
    try:
        from .model_loader import load_metadata
        return load_metadata(settings.metadata_path)
    except ModelLoadError:
        return {}


# ------------------------------------------------------------------ About
def render_about(settings, bundle) -> None:
    st.header("About and Limitations")
    render_disclaimer()
    st.markdown(
        "### What this app is\n"
        "A research/demo interface around an EfficientNetB0 image classifier (fine-tuned by the repository author) "
        "that assigns a photo to one of six categories.\n\n"
        "### Supported classes\n" + "\n".join(f"- {c}" for c in (bundle.class_names if bundle else _safe_metadata(settings).get('class_names', []))) +
        "\n\n### Known limitations\n"
        "- **Not clinically validated** and not approved by any regulator. It cannot diagnose or exclude disease.\n"
        "- **Closed set:** the model must pick one of six labels. It has no 'healthy' or 'not an oral photo' class and "
        "has not been validated for out-of-distribution detection.\n"
        "- **Scores are not calibrated probabilities.** A confident answer can still be wrong.\n"
        "- **Unknown data provenance:** the training dataset's origin, patient diversity, photo devices and labelling "
        "process are not documented in the repository.\n"
        "- The repository's test accuracy (98.44 %) comes from a held-out split of the same dataset; real-world "
        "performance is likely lower.\n"
        "- Class descriptions in this app are general educational summaries, not produced by the model.\n\n"
        "### Privacy\n"
        "Uploaded images are read in memory, are not written to disk, are not logged, and are not sent to any "
        "third-party service. Use **Clear image & results** to discard them. The optional weight download "
        "(`scripts/download_model.py`) contacts Google Drive only when you run it.\n"
    )
    if bundle:
        with st.expander("Technical details"):
            st.json({"model": bundle.model_name, "framework": bundle.framework, "input_size_hw": list(bundle.input_size),
                     "classes": bundle.class_names, "model_file": str(bundle.model_path),
                     "load_seconds": round(bundle.load_seconds, 2),
                     "preprocessing": bundle.metadata.get("preprocessing_note")})
