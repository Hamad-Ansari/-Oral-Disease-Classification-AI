"""Model + metadata loading with explicit validation and helpful troubleshooting messages."""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional


class ModelLoadError(Exception):
    """Raised when the model or its metadata cannot be used. `troubleshooting` is shown to the user."""

    def __init__(self, message: str, troubleshooting: str = ""):
        super().__init__(message)
        self.message = message
        self.troubleshooting = troubleshooting


@dataclass
class ModelBundle:
    model: Any
    class_names: list
    input_size: tuple  # (height, width)
    framework: str
    model_name: str
    model_path: Optional[Path]
    metadata: dict = field(default_factory=dict)
    load_seconds: float = 0.0

    @property
    def num_classes(self) -> int:
        return len(self.class_names)


def load_metadata(path: Path) -> dict:
    """Read and validate model_metadata.json. Raises ModelLoadError when unusable."""
    path = Path(path)
    if not path.is_file():
        raise ModelLoadError(
            f"Metadata file not found: {path}",
            "Keep model_metadata.json next to app.py, or set ORAL_METADATA_PATH to its location.",
        )
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ModelLoadError(f"Could not read {path.name}: {exc}", "Re-download model_metadata.json from the repository.") from exc

    names = data.get("class_names")
    if not isinstance(names, list) or not names or not all(isinstance(n, str) and n for n in names):
        raise ModelLoadError("model_metadata.json has no valid 'class_names' list.")
    if len(set(names)) != len(names):
        raise ModelLoadError("model_metadata.json contains duplicate class names.")
    declared = data.get("num_classes")
    if declared is not None and declared != len(names):
        raise ModelLoadError(f"num_classes ({declared}) does not match the {len(names)} listed class names.")
    size = data.get("img_size", [224, 224])
    if (not isinstance(size, (list, tuple)) or len(size) != 2
            or not all(isinstance(s, int) and s > 0 for s in size)):
        raise ModelLoadError("'img_size' must be two positive integers: [height, width].")
    return data


def _default_keras_loader(path: str):
    try:
        import tensorflow as tf  # imported lazily: tests and the 'missing model' path need no TensorFlow
    except ImportError as exc:
        raise ModelLoadError(
            "TensorFlow is not installed.",
            "Run: python -m pip install -r requirements.txt",
        ) from exc
    return tf.keras.models.load_model(path, compile=False), f"TensorFlow {tf.__version__} / Keras"


TROUBLESHOOTING_LOAD = (
    "1) Confirm the file is the original best_model.keras (not a partial download).\n"
    "2) Use a TensorFlow version close to the one used for training (see README).\n"
    "3) Re-download with: python scripts/download_model.py\n"
    "4) Set ORAL_MODEL_PATH if the file lives somewhere else."
)


def load_model_bundle(
    model_path: Path,
    metadata_path: Path,
    loader: Optional[Callable[[str], Any]] = None,
) -> ModelBundle:
    """Load metadata + model once and verify output/input shapes against the class list.

    `loader(path)` may return a model or a (model, framework_label) tuple; tests inject a fake.
    """
    metadata = load_metadata(metadata_path)
    class_names = list(metadata["class_names"])
    input_size = tuple(metadata.get("img_size", [224, 224]))

    model_path = Path(model_path)
    if not model_path.is_file():
        raise ModelLoadError(
            f"Model file not found: {model_path}",
            "The trained weights are not stored in the Git repository.\n"
            "Run: python scripts/download_model.py   (downloads from Google Drive, you are asked first)\n"
            "or copy best_model.keras into the models/ folder, or set ORAL_MODEL_PATH.",
        )
    if not os.access(model_path, os.R_OK):
        raise ModelLoadError(f"Model file is not readable: {model_path}", "Check the file permissions.")
    if model_path.stat().st_size == 0:
        raise ModelLoadError(f"Model file is empty: {model_path}", "Delete it and download the weights again.")

    start = time.perf_counter()
    try:
        result = (loader or _default_keras_loader)(str(model_path))
    except ModelLoadError:
        raise
    except Exception as exc:  # noqa: BLE001 - surface any framework error with guidance
        raise ModelLoadError(f"The model file could not be loaded: {exc}", TROUBLESHOOTING_LOAD) from exc
    model, framework = result if isinstance(result, tuple) else (result, "unknown framework")
    elapsed = time.perf_counter() - start

    _verify_shapes(model, len(class_names), input_size)
    return ModelBundle(
        model=model,
        class_names=class_names,
        input_size=input_size,
        framework=framework,
        model_name=str(metadata.get("best_model_name", "unknown")),
        model_path=model_path,
        metadata=metadata,
        load_seconds=elapsed,
    )


def _verify_shapes(model: Any, num_classes: int, input_size: tuple) -> None:
    out_shape = getattr(model, "output_shape", None)
    if out_shape is not None:
        if isinstance(out_shape, list):
            raise ModelLoadError("The model has multiple outputs; a single classification output is expected.")
        if out_shape[-1] is not None and int(out_shape[-1]) != num_classes:
            raise ModelLoadError(
                f"Model output size ({out_shape[-1]}) does not match the {num_classes} classes in model_metadata.json.",
                "Make sure best_model.keras and model_metadata.json come from the same training run.",
            )
    in_shape = getattr(model, "input_shape", None)
    if in_shape is not None and not isinstance(in_shape, list) and len(in_shape) == 4:
        h, w = in_shape[1], in_shape[2]
        if h is not None and w is not None and (int(h), int(w)) != tuple(input_size):
            raise ModelLoadError(
                f"Model input size ({h}x{w}) does not match img_size {list(input_size)} in the metadata.",
                "Fix img_size in model_metadata.json or use the matching model file.",
            )


def download_from_drive(file_id: str, dest: Path) -> Path:
    """Download the weights from Google Drive with gdown. Only called when the user opts in
    (ORAL_AUTO_DOWNLOAD=1 or scripts/download_model.py). Uploads nothing."""
    try:
        import gdown
    except ImportError as exc:
        raise ModelLoadError("gdown is not installed.", "Run: python -m pip install gdown") from exc
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        result = gdown.download(f"https://drive.google.com/uc?id={file_id}", str(dest), quiet=True)
    except Exception as exc:  # noqa: BLE001
        raise ModelLoadError(f"Download failed: {exc}", "Download the file manually and place it in models/.") from exc
    if not result or not dest.is_file() or dest.stat().st_size == 0:
        raise ModelLoadError(
            "Download failed or produced an empty file.",
            "Google Drive may be rate-limiting the file. Download it in a browser and place it in models/.",
        )
    return dest
