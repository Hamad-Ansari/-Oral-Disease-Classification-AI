"""Inference: output interpretation, validation and structured results."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .preprocessing import preprocess_image

SEMANTICS_PROBABILITIES = "softmax probability (uncalibrated)"
SEMANTICS_SOFTMAX_LOGITS = "softmax-normalised score (model emitted raw values)"

LOW_CONFIDENCE_MESSAGE = (
    "The model could not produce a sufficiently reliable prediction for this image. "
    "Try a clearer photograph or seek advice from a dental professional."
)
CALIBRATION_WARNING = (
    "Scores are NOT calibrated probabilities. A high score does not guarantee a correct result, "
    "and a low score does not mean there is no condition."
)
OOD_WARNING = (
    "The model has not been validated for out-of-distribution detection: photos that are not of "
    "these six conditions will still receive one of the six labels."
)


class InferenceError(RuntimeError):
    pass


@dataclass
class PredictionResult:
    top_class: str
    top_score: float
    scores: np.ndarray
    class_names: list
    semantics: str
    inference_ms: float
    model_name: str
    framework: str
    input_shape: tuple
    preprocessing_note: str
    low_confidence: bool = False
    warnings: list = field(default_factory=list)

    @property
    def ranking(self) -> list:
        order = np.argsort(-self.scores, kind="stable")
        return [(self.class_names[i], float(self.scores[i])) for i in order]

    def top_k(self, k: int = 3) -> list:
        return self.ranking[: max(1, k)]

    @property
    def score_label(self) -> str:
        return "Model confidence" if self.semantics == SEMANTICS_PROBABILITIES else "Model score"


def _softmax(x: np.ndarray) -> np.ndarray:
    e = np.exp(x - np.max(x))
    return e / np.sum(e)


def interpret_output(raw, num_classes: int, mode: str = "auto"):
    """Turn raw model output into (scores, semantics, warnings). Never silently assumes probabilities."""
    arr = np.asarray(raw, dtype=np.float64)
    if arr.ndim == 2 and arr.shape[0] == 1:
        arr = arr[0]
    if arr.ndim != 1:
        raise InferenceError(f"Unexpected model output dimensions: {arr.shape}.")
    if arr.shape[0] != num_classes:
        raise InferenceError(f"Model returned {arr.shape[0]} values but {num_classes} classes are configured.")
    if not np.isfinite(arr).all():
        raise InferenceError("Model output contains NaN or infinite values.")

    looks_like_probs = bool((arr >= 0).all() and (arr <= 1).all() and abs(arr.sum() - 1.0) < 1e-3)
    warnings: list = []
    if mode == "probabilities":
        if not looks_like_probs:
            raise InferenceError("ORAL_OUTPUT_ACTIVATION=probabilities but the output is not a valid distribution.")
        return arr, SEMANTICS_PROBABILITIES, warnings
    if mode == "softmax":
        return _softmax(arr), SEMANTICS_SOFTMAX_LOGITS, warnings
    if looks_like_probs:
        return arr, SEMANTICS_PROBABILITIES, warnings
    warnings.append(
        "The model output was not a probability distribution, so softmax was applied to it. "
        "Treat the numbers as relative scores only."
    )
    return _softmax(arr), SEMANTICS_SOFTMAX_LOGITS, warnings


def predict(bundle, image, settings=None) -> PredictionResult:
    """Run the full preprocess -> model -> interpretation pipeline for one PIL image."""
    mode = getattr(settings, "output_activation", "auto")
    threshold: Optional[float] = getattr(settings, "low_confidence_threshold", None)

    tensor = preprocess_image(image, bundle.input_size)
    start = time.perf_counter()
    try:
        raw = bundle.model.predict(tensor, verbose=0)
    except Exception as exc:  # noqa: BLE001
        raise InferenceError(f"The model failed while predicting: {exc}") from exc
    elapsed_ms = (time.perf_counter() - start) * 1000.0

    scores, semantics, warnings = interpret_output(raw, bundle.num_classes, mode)
    top = int(np.argmax(scores))
    top_score = float(scores[top])

    low = threshold is not None and top_score < threshold
    warnings = list(warnings)
    if low:
        warnings.insert(0, LOW_CONFIDENCE_MESSAGE)
    warnings.extend([CALIBRATION_WARNING, OOD_WARNING])

    return PredictionResult(
        top_class=bundle.class_names[top],
        top_score=top_score,
        scores=scores,
        class_names=list(bundle.class_names),
        semantics=semantics,
        inference_ms=elapsed_ms,
        model_name=bundle.model_name,
        framework=bundle.framework,
        input_shape=tuple(tensor.shape),
        preprocessing_note=str(bundle.metadata.get("preprocessing_note", "")),
        low_confidence=low,
        warnings=warnings,
    )
