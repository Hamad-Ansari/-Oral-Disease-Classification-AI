"""Preprocessing that mirrors model_metadata.json: raw RGB float32 in [0, 255], shape (1, H, W, 3).

EfficientNetB0 in Keras rescales internally, so NO /255 and NO ImageNet normalisation is applied here.
"""
from __future__ import annotations

import numpy as np
from PIL import Image, ImageOps


class PreprocessingError(ValueError):
    pass


def to_rgb(img: Image.Image) -> Image.Image:
    """Convert any Pillow mode to 8-bit RGB. Transparency is composited onto white."""
    if img.mode in ("RGBA", "LA", "PA") or (img.mode == "P" and "transparency" in img.info):
        rgba = img.convert("RGBA")
        background = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
        background.alpha_composite(rgba)
        return background.convert("RGB")
    if img.mode in ("I;16", "I;16L", "I;16B"):
        arr = np.asarray(img, dtype=np.float32) / 257.0
        return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), mode="L").convert("RGB")
    if img.mode in ("I", "F"):
        arr = np.asarray(img, dtype=np.float32)
        return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), mode="L").convert("RGB")
    return img.convert("RGB")


def processed_preview(img: Image.Image, target_size: tuple[int, int]) -> Image.Image:
    """The exact 8-bit image the model will see (target_size is (height, width))."""
    height, width = target_size
    rgb = to_rgb(ImageOps.exif_transpose(img))
    return rgb.resize((width, height), Image.Resampling.BILINEAR)


def preprocess_image(img: Image.Image, target_size: tuple[int, int] = (224, 224)) -> np.ndarray:
    """Return a float32 tensor of shape (1, H, W, 3) with values in [0, 255]."""
    if img is None or img.size[0] == 0 or img.size[1] == 0:
        raise PreprocessingError("Cannot preprocess an empty image.")
    arr = np.asarray(processed_preview(img, target_size), dtype=np.float32)
    height, width = target_size
    if arr.shape != (height, width, 3):
        raise PreprocessingError(f"Unexpected tensor shape {arr.shape}; expected {(height, width, 3)}.")
    if not np.isfinite(arr).all():
        raise PreprocessingError("Image tensor contains NaN or infinite values.")
    if arr.min() < 0.0 or arr.max() > 255.0:
        raise PreprocessingError("Image tensor values fall outside [0, 255].")
    return np.expand_dims(arr, axis=0)
