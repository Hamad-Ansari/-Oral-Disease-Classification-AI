"""Plain-language class descriptions.

PROVENANCE: the original repository ships class names only. The text below is a short, general
educational summary written for this app from widely published dental information. It is NOT derived
from the model or its training data and has not been reviewed by a clinician - have a dental
professional review it before any real-world use.
"""
from __future__ import annotations

from typing import Optional

SOURCE_NOTE = (
    "General educational summary written for this app. It is not produced by the model and has not "
    "been clinically reviewed."
)

GENERAL_NEXT_STEP = (
    "Please consult a qualified dentist or doctor. They can examine you in person, which a photo-based "
    "tool cannot replace."
)

_INFO = {
    "Calculus": {
        "description": "Calculus (tartar) is plaque that has hardened on the teeth, often near the gum line.",
        "meaning": "The model found this image most similar to examples labelled calculus.",
        "next_step": "Calculus cannot be brushed off; a dentist or hygienist removes it with a professional cleaning.",
    },
    "Caries": {
        "description": "Caries (tooth decay) is damage to tooth structure caused by acids from bacteria in dental plaque.",
        "meaning": "The model found this image most similar to examples labelled caries.",
        "next_step": "Early decay is easier to treat, so book a dental check-up, especially if there is pain or sensitivity.",
    },
    "Gingivitis": {
        "description": "Gingivitis is inflammation of the gums, commonly with redness, swelling or bleeding when brushing.",
        "meaning": "The model found this image most similar to examples labelled gingivitis.",
        "next_step": "Early gum inflammation is often reversible with good cleaning habits and a professional check.",
    },
    "Hypodontia": {
        "description": "Hypodontia means one or more teeth are missing because they never developed.",
        "meaning": "The model found this image most similar to examples labelled hypodontia.",
        "next_step": "A dentist or orthodontist can confirm this (often with X-rays) and discuss options.",
    },
    "Mouth Ulcer": {
        "description": "A mouth ulcer is a painful sore on the soft tissues inside the mouth.",
        "meaning": "The model found this image most similar to examples labelled mouth ulcer.",
        "next_step": "Many ulcers heal on their own, but have any sore that lasts more than about three weeks examined.",
    },
    "Tooth Discoloration": {
        "description": "Tooth discoloration is a change in tooth colour, caused by surface stains or by changes inside the tooth.",
        "meaning": "The model found this image most similar to examples labelled tooth discoloration.",
        "next_step": "A dentist can tell which kind of discoloration it is and whether any treatment is advisable.",
    },
}


def get_class_info(class_name: str) -> Optional[dict]:
    """Return info for a class, or None when the class is unknown (the UI then degrades gracefully)."""
    return _INFO.get(class_name)
