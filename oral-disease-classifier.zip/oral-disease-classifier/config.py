"""Centralised configuration. Every value can be overridden with an environment variable."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent

# Google Drive file id taken from the original repository's app.py (weights are NOT in the git repo).
DEFAULT_DRIVE_MODEL_ID = "1GsTgzh5wDQEZw26bHxDu4wWvNNO83Fq5"


def _env_float(name: str, default: float | None) -> float | None:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    try:
        return int(raw) if raw not in (None, "") else default
    except ValueError:
        return default


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _resolve_model_path(root: Path) -> Path:
    """ORAL_MODEL_PATH wins; otherwise models/best_model.keras, then ./best_model.keras (legacy)."""
    env = os.getenv("ORAL_MODEL_PATH")
    if env:
        return Path(env).expanduser()
    for candidate in (root / "models" / "best_model.keras", root / "best_model.keras"):
        if candidate.exists():
            return candidate
    return root / "models" / "best_model.keras"


@dataclass(frozen=True)
class Settings:
    app_name: str
    project_root: Path
    model_path: Path
    metadata_path: Path
    eval_dir: Path
    figures_dir: Path
    sample_dir: Path
    allowed_extensions: tuple
    allowed_formats: tuple
    max_upload_mb: float
    min_side_px: int
    max_side_px: int
    max_pixels: int
    top_k: int
    low_confidence_threshold: float | None
    output_activation: str  # "auto" | "probabilities" | "softmax"
    auto_download: bool
    drive_model_id: str

    @property
    def max_upload_bytes(self) -> int:
        return int(self.max_upload_mb * 1024 * 1024)

    @classmethod
    def from_env(cls, root: Path = PROJECT_ROOT) -> "Settings":
        activation = os.getenv("ORAL_OUTPUT_ACTIVATION", "auto").strip().lower()
        if activation not in {"auto", "probabilities", "softmax"}:
            activation = "auto"
        metadata_env = os.getenv("ORAL_METADATA_PATH")
        return cls(
            app_name="Oral Disease Classification AI",
            project_root=root,
            model_path=_resolve_model_path(root),
            metadata_path=Path(metadata_env).expanduser() if metadata_env else root / "model_metadata.json",
            eval_dir=root / "reports" / "evaluation",
            figures_dir=root / "reports" / "figures",
            sample_dir=root / "assets" / "sample_images",
            allowed_extensions=("jpg", "jpeg", "png"),
            allowed_formats=("JPEG", "PNG"),
            max_upload_mb=_env_float("ORAL_MAX_UPLOAD_MB", 10.0) or 10.0,
            min_side_px=_env_int("ORAL_MIN_SIDE_PX", 64),
            max_side_px=_env_int("ORAL_MAX_SIDE_PX", 8000),
            max_pixels=_env_int("ORAL_MAX_PIXELS", 40_000_000),
            top_k=_env_int("ORAL_TOP_K", 3),
            # Disabled by default: no calibration / validation data exists to justify a cut-off.
            low_confidence_threshold=_env_float("ORAL_LOW_CONFIDENCE_THRESHOLD", None),
            output_activation=activation,
            auto_download=_env_bool("ORAL_AUTO_DOWNLOAD", False),
            drive_model_id=os.getenv("ORAL_DRIVE_MODEL_ID", DEFAULT_DRIVE_MODEL_ID),
        )


def get_settings() -> Settings:
    return Settings.from_env()
