import io

import pytest
from PIL import Image

from src.validation import ImageValidationError, assess_quality, validate_upload
from tests.conftest import make_bytes


def test_valid_png_and_jpeg(settings):
    for fmt, name in (("PNG", "a.png"), ("JPEG", "b.jpg")):
        img, info = validate_upload(make_bytes("RGB", fmt=fmt), name, settings)
        assert info.format == fmt and img.size == (300, 200) and len(info.sha256) == 64


def test_empty_file(settings):
    with pytest.raises(ImageValidationError, match="empty"):
        validate_upload(b"", "a.png", settings)


def test_unsupported_extension(settings):
    with pytest.raises(ImageValidationError, match="Unsupported"):
        validate_upload(make_bytes(), "a.gif", settings)


def test_extension_lies_about_content(settings):
    buf = io.BytesIO()
    Image.new("RGB", (200, 200)).save(buf, format="BMP")
    with pytest.raises(ImageValidationError, match="not JPEG or PNG"):
        validate_upload(buf.getvalue(), "fake.png", settings)


def test_corrupted_bytes(settings):
    with pytest.raises(ImageValidationError, match="could not be read"):
        validate_upload(b"this is definitely not an image" * 10, "a.png", settings)


def test_truncated_image(settings):
    data = make_bytes("RGB", size=(400, 400), fmt="PNG")
    with pytest.raises(ImageValidationError):
        validate_upload(data[: len(data) // 2], "a.png", settings)


def test_too_large_file(settings):
    from dataclasses import replace
    tiny = replace(settings, max_upload_mb=0.001)
    with pytest.raises(ImageValidationError, match="too large"):
        validate_upload(make_bytes(size=(400, 400)), "a.png", tiny)


def test_too_small_and_too_big_dimensions(settings):
    from dataclasses import replace
    with pytest.raises(ImageValidationError, match="too small"):
        validate_upload(make_bytes(size=(20, 20)), "a.png", settings)
    capped = replace(settings, max_side_px=100)
    with pytest.raises(ImageValidationError, match="dimensions are too large"):
        validate_upload(make_bytes(size=(300, 200)), "a.png", capped)


def test_exif_orientation_is_applied(settings):
    img = Image.new("RGB", (300, 100), (10, 200, 10))
    exif = Image.Exif()
    exif[0x0112] = 6  # rotate 90 degrees
    buf = io.BytesIO()
    img.save(buf, format="JPEG", exif=exif)
    out, info = validate_upload(buf.getvalue(), "r.jpg", settings)
    assert out.size == (100, 300) and (info.width, info.height) == (100, 300)


def test_quality_hints_are_heuristic_only():
    dark = Image.new("RGB", (300, 300), (5, 5, 5))
    hints = assess_quality(dark)
    assert any("dark" in h for h in hints)
    assert assess_quality(Image.new("RGB", (100, 100), (128, 128, 128)), (224, 224))
