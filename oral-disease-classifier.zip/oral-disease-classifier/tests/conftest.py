import io
import json
import sys
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from config import Settings  # noqa: E402

CLASSES = ["Calculus", "Caries", "Gingivitis", "Hypodontia", "Mouth Ulcer", "Tooth Discoloration"]


@pytest.fixture()
def settings():
    return Settings.from_env(ROOT)


def make_bytes(mode="RGB", size=(300, 200), fmt="PNG", color=None):
    color = color if color is not None else {"RGB": (200, 80, 80), "RGBA": (200, 80, 80, 128),
                                              "L": 120, "P": 5}.get(mode, 0)
    img = Image.new(mode, size, color)
    # add some texture so contrast checks are not degenerate
    arr = np.asarray(img.convert("RGB")).copy()
    arr[::7, :, :] = 255
    img = Image.fromarray(arr).convert(mode) if mode in ("RGB", "L") else img
    buf = io.BytesIO()
    img.save(buf, format=fmt)
    return buf.getvalue()


@pytest.fixture()
def rgb_png():
    return make_bytes("RGB", fmt="PNG")


@pytest.fixture()
def metadata_file(tmp_path):
    p = tmp_path / "meta.json"
    p.write_text(json.dumps({"class_names": CLASSES, "num_classes": 6, "img_size": [224, 224],
                             "best_model_name": "FakeNet", "preprocessing_note": "raw 0-255"}))
    return p


class FakeModel:
    """Minimal stand-in exposing the Keras surface the app uses."""

    def __init__(self, output, output_shape=(None, 6), input_shape=(None, 224, 224, 3)):
        self._output = np.asarray(output, dtype=np.float32)
        self.output_shape = output_shape
        self.input_shape = input_shape
        self.last_input = None

    def predict(self, x, verbose=0):
        self.last_input = x
        return self._output.reshape(1, -1) if self._output.ndim == 1 else self._output


@pytest.fixture()
def fake_bundle(metadata_file):
    from src.model_loader import load_model_bundle
    model_file = metadata_file.parent / "fake.keras"
    model_file.write_bytes(b"not-a-real-model")
    probs = [0.02, 0.9, 0.03, 0.02, 0.02, 0.01]
    return load_model_bundle(model_file, metadata_file, loader=lambda p: (FakeModel(probs), "FakeFramework"))
