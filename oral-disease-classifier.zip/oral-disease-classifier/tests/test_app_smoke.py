"""Runs the real Streamlit script headlessly with no model file present: it must degrade gracefully."""
import pytest

pytest.importorskip("streamlit")
from streamlit.testing.v1 import AppTest  # noqa: E402

from tests.conftest import ROOT  # noqa: E402


@pytest.fixture()
def no_model_env(monkeypatch, tmp_path):
    monkeypatch.setenv("ORAL_MODEL_PATH", str(tmp_path / "absent.keras"))


@pytest.mark.parametrize("page", ["Home", "Image Analysis", "Model Insights", "About and Limitations"])
def test_every_page_renders_without_model(no_model_env, page):
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    assert not at.exception
    at.sidebar.radio[0].set_value(page).run()
    assert not at.exception, [e.value for e in at.exception]


def test_analysis_page_explains_missing_model(no_model_env):
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    at.sidebar.radio[0].set_value("Image Analysis").run()
    assert any("Model not available" in e.value for e in at.error)
