import numpy as np
import pytest
from PIL import Image

from src.preprocessing import PreprocessingError, preprocess_image, to_rgb


@pytest.mark.parametrize("mode", ["RGB", "RGBA", "L", "P", "LA"])
def test_output_shape_dtype_range_for_all_modes(mode):
    img = Image.new(mode, (321, 123), 100 if mode in ("L", "P") else ((90, 90, 90, 255) if mode == "RGBA" else (90, 255) if mode == "LA" else 0))
    out = preprocess_image(img, (224, 224))
    assert out.shape == (1, 224, 224, 3) and out.dtype == np.float32
    assert 0.0 <= out.min() and out.max() <= 255.0


def test_no_rescaling_values_stay_raw_0_255():
    img = Image.new("RGB", (50, 50), (255, 0, 128))
    out = preprocess_image(img, (224, 224))
    assert np.allclose(out[0, 0, 0], [255, 0, 128], atol=1)


def test_transparency_composited_on_white():
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    assert to_rgb(img).getpixel((0, 0)) == (255, 255, 255)


def test_unusual_aspect_ratio_is_resized_not_cropped():
    img = Image.new("RGB", (1000, 40), (10, 20, 30))
    assert preprocess_image(img, (224, 224)).shape == (1, 224, 224, 3)


def test_non_square_target_uses_height_width_order():
    img = Image.new("RGB", (100, 100))
    assert preprocess_image(img, (160, 192)).shape == (1, 160, 192, 3)


def test_16bit_grayscale_png():
    arr = (np.random.rand(80, 80) * 65535).astype(np.uint16)
    img = Image.fromarray(arr)
    out = preprocess_image(img, (224, 224))
    assert out.max() <= 255.0 and out.shape[-1] == 3


def test_none_image_rejected():
    with pytest.raises(PreprocessingError):
        preprocess_image(None)
