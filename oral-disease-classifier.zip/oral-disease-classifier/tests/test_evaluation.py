import numpy as np
import pandas as pd

from src import evaluation as ev
from src import visualizations as viz
from src.model_loader import load_metadata


def _cm(settings, name):
    return ev.load_confusion_matrix(settings.eval_dir / ev.CONFUSION_FILES[name])


def test_matrices_match_repo_metadata(settings):
    meta = load_metadata(settings.metadata_path)
    for name, acc in (("EfficientNetB0", 0.9844), ("Custom_CNN", 0.5353)):
        cm = _cm(settings, name)
        assert cm is not None and cm.values.sum() == 1599
        assert abs(ev.summary_from_cm(cm)["accuracy"] - acc) < 0.0006
        assert ev.cross_check_with_metadata(cm, name, meta) == []


def test_efficientnet_macro_metrics_match_metadata(settings):
    meta = load_metadata(settings.metadata_path)["test_metrics"]
    s = ev.summary_from_cm(_cm(settings, "EfficientNetB0"))
    for key in ("accuracy", "macro_precision", "macro_recall", "macro_f1", "weighted_f1"):
        assert abs(s[key] - meta[key]) < 0.0006, key


def test_class_distribution_total(settings):
    df = ev.load_class_distribution(settings.eval_dir)
    assert int(df["images"].sum()) == 10656


def test_zero_observation_class_does_not_crash():
    cm = pd.DataFrame([[5, 0], [0, 0]], index=["a", "b"], columns=["a", "b"])
    rep = ev.classification_report_from_cm(cm)
    assert rep.loc[1, "F1-score"] == 0 and np.isfinite(rep.select_dtypes("number").values).all()
    fig = viz.confusion_matrix_fig(cm, "t", normalize=True)
    assert fig is not None


def test_confusion_matrix_figures_have_labels(settings):
    import matplotlib.pyplot as plt
    cm = _cm(settings, "EfficientNetB0")
    for norm in (False, True):
        fig = viz.confusion_matrix_fig(cm, "EfficientNetB0", normalize=norm)
        ax = fig.axes[0]
        assert ax.get_xlabel() == "Predicted label" and ax.get_ylabel() == "True label"
        assert [t.get_text() for t in ax.get_xticklabels()] == list(cm.columns)
        plt.close(fig)


def test_missing_and_invalid_files_return_none(tmp_path):
    assert ev.load_confusion_matrix(tmp_path / "missing.csv") is None
    bad = tmp_path / "bad.csv"
    bad.write_text("x,a,b\nr1,1,2\n")
    assert ev.load_confusion_matrix(bad) is None
    assert ev.load_class_distribution(tmp_path) is None
    assert "not available" in ev.missing_artifacts_message(tmp_path, ["x.csv"])


def test_prediction_bar_sorted_and_top3():
    ranking = [("A", 0.7), ("B", 0.2), ("C", 0.1)]
    fig = viz.prediction_bar(ranking)
    assert list(fig.data[0].y)[-1] == "A"  # highest on top of a horizontal chart
