import json

import pytest

from src.model_loader import ModelLoadError, load_metadata, load_model_bundle
from tests.conftest import CLASSES, FakeModel


def test_successful_load_reports_info(fake_bundle):
    assert fake_bundle.num_classes == 6 and fake_bundle.class_names == CLASSES
    assert fake_bundle.framework == "FakeFramework" and fake_bundle.input_size == (224, 224)


def test_missing_model_artifact_gives_troubleshooting(tmp_path, metadata_file):
    with pytest.raises(ModelLoadError) as err:
        load_model_bundle(tmp_path / "nope.keras", metadata_file, loader=lambda p: FakeModel([0] * 6))
    assert "not found" in err.value.message and "download_model.py" in err.value.troubleshooting


def test_empty_model_file(tmp_path, metadata_file):
    f = tmp_path / "e.keras"
    f.write_bytes(b"")
    with pytest.raises(ModelLoadError, match="empty"):
        load_model_bundle(f, metadata_file, loader=lambda p: FakeModel([0] * 6))


def test_loader_exception_is_wrapped(tmp_path, metadata_file):
    f = tmp_path / "m.keras"
    f.write_bytes(b"x")

    def boom(_):
        raise RuntimeError("bad zip")

    with pytest.raises(ModelLoadError, match="could not be loaded") as err:
        load_model_bundle(f, metadata_file, loader=boom)
    assert err.value.troubleshooting


def test_output_shape_mismatch_detected(tmp_path, metadata_file):
    f = tmp_path / "m.keras"
    f.write_bytes(b"x")
    with pytest.raises(ModelLoadError, match="output size"):
        load_model_bundle(f, metadata_file, loader=lambda p: FakeModel([0] * 5, output_shape=(None, 5)))


def test_input_size_mismatch_detected(tmp_path, metadata_file):
    f = tmp_path / "m.keras"
    f.write_bytes(b"x")
    with pytest.raises(ModelLoadError, match="input size"):
        load_model_bundle(f, metadata_file, loader=lambda p: FakeModel([0] * 6, input_shape=(None, 128, 128, 3)))


def test_class_index_consistency_in_metadata(tmp_path):
    bad = tmp_path / "m.json"
    bad.write_text(json.dumps({"class_names": ["a", "b"], "num_classes": 3}))
    with pytest.raises(ModelLoadError, match="num_classes"):
        load_metadata(bad)
    dup = tmp_path / "d.json"
    dup.write_text(json.dumps({"class_names": ["a", "a"]}))
    with pytest.raises(ModelLoadError, match="duplicate"):
        load_metadata(dup)


def test_real_repo_metadata_is_consistent(settings):
    meta = load_metadata(settings.metadata_path)
    assert meta["class_names"] == CLASSES and meta["img_size"] == [224, 224]


def test_missing_metadata(tmp_path):
    with pytest.raises(ModelLoadError, match="Metadata file not found"):
        load_metadata(tmp_path / "none.json")


def test_drive_download_uses_gdown_and_validates_result(tmp_path, monkeypatch):
    import sys
    import types

    from src.model_loader import download_from_drive

    calls = {}

    def fake_download(url, out, quiet=True):
        calls["url"] = url
        open(out, "wb").write(b"weights")
        return out

    monkeypatch.setitem(sys.modules, "gdown", types.SimpleNamespace(download=fake_download))
    dest = download_from_drive("FILEID", tmp_path / "sub" / "m.keras")
    assert dest.read_bytes() == b"weights" and calls["url"].endswith("FILEID")

    monkeypatch.setitem(sys.modules, "gdown", types.SimpleNamespace(download=lambda *a, **k: None))
    with pytest.raises(ModelLoadError, match="Download failed"):
        download_from_drive("FILEID", tmp_path / "x.keras")
