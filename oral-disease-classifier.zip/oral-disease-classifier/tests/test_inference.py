import numpy as np
import pytest
from PIL import Image

from dataclasses import replace

from src.inference import (CALIBRATION_WARNING, LOW_CONFIDENCE_MESSAGE, SEMANTICS_PROBABILITIES,
                           SEMANTICS_SOFTMAX_LOGITS, InferenceError, interpret_output, predict)
from tests.conftest import FakeModel


def test_probabilities_pass_through():
    scores, sem, warn = interpret_output([0.1, 0.2, 0.7], 3)
    assert sem == SEMANTICS_PROBABILITIES and np.allclose(scores, [0.1, 0.2, 0.7]) and not warn


def test_logits_get_softmax_and_a_warning():
    scores, sem, warn = interpret_output([2.0, 1.0, -1.0], 3)
    assert sem == SEMANTICS_SOFTMAX_LOGITS and np.isclose(scores.sum(), 1.0) and warn


@pytest.mark.parametrize("bad", [[np.nan, 0.5, 0.5], [np.inf, 0.0, 0.0]])
def test_nan_and_inf_rejected(bad):
    with pytest.raises(InferenceError, match="NaN or infinite"):
        interpret_output(bad, 3)


def test_wrong_length_and_wrong_dims_rejected():
    with pytest.raises(InferenceError, match="classes are configured"):
        interpret_output([0.5, 0.5], 3)
    with pytest.raises(InferenceError, match="dimensions"):
        interpret_output(np.zeros((2, 3)), 3)


def test_forced_probabilities_mode_rejects_logits():
    with pytest.raises(InferenceError):
        interpret_output([3.0, 1.0, 0.0], 3, mode="probabilities")


def test_predict_returns_structured_result(fake_bundle, settings):
    img = Image.new("RGB", (400, 300), (180, 60, 60))
    res = predict(fake_bundle, img, settings)
    assert res.top_class == "Caries" and abs(res.top_score - 0.9) < 1e-6
    assert [n for n, _ in res.top_k(3)][0] == "Caries" and len(res.top_k(3)) == 3
    assert res.input_shape == (1, 224, 224, 3) and res.inference_ms >= 0
    assert res.score_label == "Model confidence"
    assert CALIBRATION_WARNING in res.warnings and not res.low_confidence
    assert fake_bundle.model.last_input.max() <= 255.0  # raw 0-255, not rescaled


def test_low_confidence_handling(fake_bundle, settings):
    fake_bundle.model = FakeModel([0.3, 0.25, 0.2, 0.1, 0.1, 0.05])
    strict = replace(settings, low_confidence_threshold=0.6)
    res = predict(fake_bundle, Image.new("RGB", (300, 300)), strict)
    assert res.low_confidence and res.warnings[0] == LOW_CONFIDENCE_MESSAGE
    off = predict(fake_bundle, Image.new("RGB", (300, 300)), settings)
    assert not off.low_confidence  # disabled by default: no validated threshold exists


def test_model_failure_is_wrapped(fake_bundle, settings):
    class Broken:
        def predict(self, *a, **k):
            raise ValueError("kaboom")
    fake_bundle.model = Broken()
    with pytest.raises(InferenceError, match="kaboom"):
        predict(fake_bundle, Image.new("RGB", (300, 300)), settings)


def test_invalid_output_shape_from_model(fake_bundle, settings):
    fake_bundle.model = FakeModel([0.5, 0.5], output_shape=(None, 6))
    with pytest.raises(InferenceError):
        predict(fake_bundle, Image.new("RGB", (300, 300)), settings)


def test_real_model_integration_if_available(settings):
    if not settings.model_path.is_file():
        pytest.skip("best_model.keras not present; place it in models/ to enable this integration test")
    from src.model_loader import load_model_bundle
    bundle = load_model_bundle(settings.model_path, settings.metadata_path)
    res = predict(bundle, Image.new("RGB", (500, 400), (200, 120, 110)), settings)
    assert res.top_class in bundle.class_names and np.isclose(res.scores.sum(), 1.0, atol=1e-3)
