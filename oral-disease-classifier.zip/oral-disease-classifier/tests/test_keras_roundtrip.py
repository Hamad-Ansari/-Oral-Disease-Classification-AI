"""Real TensorFlow/Keras round-trip with a tiny stand-in network (NOT the trained model).

It proves the default loader, shape checks and prediction path work with a genuine .keras file.
"""
import pytest
from PIL import Image

tf = pytest.importorskip("tensorflow")

from src.inference import predict  # noqa: E402
from src.model_loader import ModelLoadError, load_model_bundle  # noqa: E402


def _tiny_model(num_classes=6):
    inputs = tf.keras.Input(shape=(224, 224, 3))
    x = tf.keras.layers.Rescaling(1 / 255.0)(inputs)
    x = tf.keras.layers.GlobalAveragePooling2D()(x)
    outputs = tf.keras.layers.Dense(num_classes, activation="softmax")(x)
    return tf.keras.Model(inputs, outputs)


def test_save_load_predict(tmp_path, settings, metadata_file):
    path = tmp_path / "tiny.keras"
    _tiny_model().save(path)
    bundle = load_model_bundle(path, metadata_file)
    assert "TensorFlow" in bundle.framework
    res = predict(bundle, Image.new("RGB", (300, 260), (200, 100, 90)), settings)
    assert abs(res.scores.sum() - 1.0) < 1e-4 and res.top_class in bundle.class_names


def test_wrong_class_count_is_rejected(tmp_path, metadata_file):
    path = tmp_path / "five.keras"
    _tiny_model(5).save(path)
    with pytest.raises(ModelLoadError, match="output size"):
        load_model_bundle(path, metadata_file)


def test_garbage_file_is_a_friendly_error(tmp_path, metadata_file):
    path = tmp_path / "garbage.keras"
    path.write_bytes(b"definitely not a keras archive")
    with pytest.raises(ModelLoadError, match="could not be loaded"):
        load_model_bundle(path, metadata_file)
