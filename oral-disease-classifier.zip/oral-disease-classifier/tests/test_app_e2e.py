"""End-to-end: upload -> validate -> Analyze Image -> result card, using the real Streamlit script.

A tiny stand-in Keras network replaces the trained weights (which are not in the Git repository),
so this verifies the pipeline wiring, not the clinical quality of the real model.
"""
import io

import pytest
from PIL import Image

tf = pytest.importorskip("tensorflow")
pytest.importorskip("streamlit")
from streamlit.testing.v1 import AppTest  # noqa: E402

from tests.conftest import ROOT  # noqa: E402


@pytest.fixture()
def app_with_tiny_model(tmp_path, monkeypatch):
    inputs = tf.keras.Input(shape=(224, 224, 3))
    x = tf.keras.layers.GlobalAveragePooling2D()(tf.keras.layers.Rescaling(1 / 255.0)(inputs))
    model = tf.keras.Model(inputs, tf.keras.layers.Dense(6, activation="softmax")(x))
    path = tmp_path / "tiny.keras"
    model.save(path)
    monkeypatch.setenv("ORAL_MODEL_PATH", str(path))
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=120).run()
    at.sidebar.radio[0].set_value("Image Analysis").run()
    return at


def _png():
    buf = io.BytesIO()
    Image.new("RGB", (400, 300), (190, 90, 80)).save(buf, format="PNG")
    return buf.getvalue()


def test_upload_analyze_shows_prediction(app_with_tiny_model):
    at = app_with_tiny_model
    assert not at.exception
    at.get("file_uploader")[0].upload("photo.png", _png(), "image/png")
    at.run()
    assert not at.error
    assert not any("Most likely category" in m.value for m in at.markdown)  # no inference before the click
    [b for b in at.button if b.label == "Analyze Image"][0].click().run()
    assert not at.exception
    cards = [m.value for m in at.markdown if "Most likely category" in m.value]
    assert len(cards) == 1 and "Model confidence" in cards[0]
    at.run()  # ordinary rerun keeps the stored result
    assert any("Most likely category" in m.value for m in at.markdown)


def test_invalid_upload_shows_friendly_error(app_with_tiny_model):
    at = app_with_tiny_model
    at.get("file_uploader")[0].upload("bad.png", b"not an image" * 10, "image/png")
    at.run()
    assert any("could not be read" in e.value for e in at.error)
    assert not [b for b in at.button if b.label == "Analyze Image"]  # nothing to analyze
