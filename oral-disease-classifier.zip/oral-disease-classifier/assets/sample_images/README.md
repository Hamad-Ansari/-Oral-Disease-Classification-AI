# Sample images (optional)

The original repository ships no individual sample photographs (only a 6-image result figure), so this folder
is intentionally empty and the app shows no sample picker.

If you have images you are legally and ethically allowed to share, put JPG/PNG files here and a
"choose a sample image" selector appears automatically in **Image Analysis**. Never add patient photos.
