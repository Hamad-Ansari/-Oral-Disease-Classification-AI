# Evaluation artifacts - provenance

All numbers here come from the original repository (`mhmdsalah10/oral-disease-classifier`). Nothing is invented.

| File | Source | How it was produced |
|---|---|---|
| `efficientnetb0_confusion_matrix.csv` | `confusion_matrices_side_by_side.png` (right panel) | Counts transcribed by hand from the figure |
| `custom_cnn_confusion_matrix.csv` | same figure (left panel) | Counts transcribed by hand from the figure |
| `class_distribution_all_images.csv` | `class_distribution.png` | Bar labels (total 10,656). The figure does not say how these split into train/val/test |

Verification: `tests/test_evaluation.py` recomputes accuracy and per-class F1 from the matrices and checks them
against `model_metadata.json` (EfficientNetB0 accuracy 98.44 %, Custom_CNN 53.53 %, all per-class F1 values).
If you re-run evaluation yourself, replace these CSVs (rows = true label, columns = predicted label, same format).
