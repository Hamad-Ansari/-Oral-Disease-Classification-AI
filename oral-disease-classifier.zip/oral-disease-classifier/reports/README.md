# reports/

- `figures/` - PNG figures copied unchanged from the original repository (class distribution, confusion matrices,
  six sample test predictions).
- `evaluation/` - machine-readable CSVs used by the **Model Insights** page, with provenance in `evaluation/README.md`.

Optional: add `evaluation/training_history.csv` after you re-run training to enable curves (not used by default).
